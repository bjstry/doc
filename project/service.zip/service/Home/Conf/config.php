<?php
return array(
	//'配置项'=>'配置值'
	'APP_DEBUG' => true, // 开启调试模式 
	//'SHOW_PAGE_TRACE' =>false,   // 显示页面Trace信息
	'DB_TYPE'=> 'mysql',    // 数据库类型 
	'DB_HOST'=> 'fangxinworld.mysql.domeneshop.no', // 数据库朋务器地址 
	'DB_NAME'=>'fangxinworld',  // 数据库名称 
	'DB_USER'=>'fangxinworld', // 数据库用户名 
	'DB_PWD'=>'YL9Ppsiu', // 数据库密码 
	'DB_PORT'=>'3306', // 数据库端口 
	'DB_PREFIX'=>'think_', // 数据表前缀 
);
?>
