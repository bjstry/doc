<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta charset=utf-8"/>
		<style type="text/css">
		fieldset {
			width: 500px;
			height: 800px;
			margin: 40px auto;
			border: 1px dotted #61B5CF;
    		padding: 20px;
		}
		legend {
			font: bold 2em Arial, Helvetica, sans-serif;
    		color: #00008B;
    		background-color: #FFFFFF;
    		border: 1px dotted #61B5CF;
		}
		</style>
	</head>
	<body>	
		<fieldset>
			<img src = "/service__PUBLIC__/images/logn1.png" width = "600px" height = "800px"/></img>
			<legend>平台使用说明</legend>
			
		</fieldset>
	</body>
</html>