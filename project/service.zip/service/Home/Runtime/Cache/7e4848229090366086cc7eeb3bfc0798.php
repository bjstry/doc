<?php if (!defined('THINK_PATH')) exit();?><html>
	<frameset rows = "20%,*" frameBorder=0 >
		<frame src = "__URL__/top.html" name = "top" noresize=true scrolling=no>
		<frameset cols = "13%,*" frameBorder=0>
			<frame src = "__URL__/left.html" name = "left" noresize=true scrolling=no>
			<frame src = "__APP__/Apply/applyTip.html" name = "right" >
		</frameset>
	</frameset>
</html>