fileProtectionChecker = true;
