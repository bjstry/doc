<?php
	define('APP_PATH','./Home/');
	define('APP_DEBUG', true);
	require './ThinkPHP/ThinkPHP.php';
?>
