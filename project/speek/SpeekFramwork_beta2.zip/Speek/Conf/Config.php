<?php
return array(
	'DT_MODEL'         =>'Home',
	'DT_URLTYPE'       =>3,
	'DT_CONTROLLER'    =>'Index',
	'DT_ACTION'        =>'Index',
	'DT_C_NAME'        =>'C',
	'DT_M_NAME'        =>'M',
	'DT_CHARSET'       =>'utf-8',
	'DT_THEME'         =>'default',
	'DT_V_EXT'          =>'.html',
	'DT_V_CACHE'       =>'false',
	'DT_V_VDIR'        =>PRJ.'/T/',
	'DT_V_VCDIR'       =>PRJ.'/T_c/',
	'DT_V_VCACHE'      =>PRJ.'/T_cache/',
	'DT_V_LEFT'        =>'{',
	'DT_V_RIGHT'       =>'}',
);
?>
