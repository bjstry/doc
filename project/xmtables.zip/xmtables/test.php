<?php
	include_once('./lib/config.php');


	$view = new View();
	$view->display('bai');
?>
