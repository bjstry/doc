=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
-                                                                             -
=          README_NECSX.txt                                                   =
-                                                                             -
=          020129 by S.Haberhauer (NEC-ESS) email: shaberhauer@nec.ch         =
-                                                                             -
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

This README file contains some hints for installation of CPMD on the NEC-SX
series

(1) Install the sources from the archive file

(2) Check for the file named "Configure"
    The architecture specific settings are set for the cross-compiling
    environment as installed on the SUN file-server at CSCS (dom.cscs.ch)
    At other sites check & adapt the following:
    (a) name of the crosscompiler commands (sxcc,sxf90)
    (b) the searchpath to the libraries (/apps/mathkeisan/lib) in the LFLAGS
    
    
    Configure <ARCH> > Makefile_conf
    
    <ARCH> is one of "NEC-SX4", "NEC-SX5", "NEC-SX5-MPI"
    
    "Makefile_conf" contains already an initial Makefile
    
(3) Applying tunings for certain targets
    Testruns showed that some subroutines could be speeded up significantly
    by applying a few specific compiling directives. The necessary 
    modifications are inserted into the Makefile by 
    
     sed 's/\$(OBJECTS:.o=.f) :/\$(OBJECTS:.o=.f) : util.f/' < Makefile_conf | gawk -f make_opt_NECSX.awk > Makefile_opt
    
    If you don't have 'gawk' installed you can also use the 'awk' of the
    system, however this might cause some errors in the output

(4) Compile & link the system

    gmake -f Makefile_opt 
    
    will generate the executable "cpmd.x"
    (the process takes about 2h on CSCS' Sun E450 system 'dom.cscs.ch')

