Instructions to compile cpmd.exe on Windows XP.

1) Get the GFortran binaries version 4.1 or later (unless 4.1 is 
offcially released, you can get snapshots from:
http://gcc.gnu.org/wiki/GFortranBinaries)

2) Get a compatible BLAS/LAPACK.
   You can compile BLAS/LAPACK from source with gfortran, 
   but the resulting binary will be sllloooooowwwww.
   For good performance you need ATLAS, MKL or ACML.
   If you cannot find a gfortran ACML ( www.developwithamd.com )
   from AMD, download the g77 version (they also work with non-AMD cpus!)

2a) To remove the g77 dependency of ATLAS/ACML:
   - compile libg77compat.c with: gcc -D__WINNT -c -O libg77compat.c
   - delete xerbla.o from ATLAS/ACML, e.g. with: ar d libacml.a xerbla.o
   - add then new object with: ar rcsv libacml.a libg77compat.o
 the resulting new library can now be used regardless of the fortran runtime,
 i.e. you can use the thusly patched libacml for g77 with intel ifort
 and it is not limited to windows (works fine on linux).

3) You have to compile 'outside of the sources directory' (see manual),
   i.e. create a directory x86-gfortran on the same level as the SOURCE
   directory and copy Makefile.winnt from here into that directory and
   rename it to Makefile. Copy the patched acml into that diretory
   as well as the file irat.inc (make sure it has IRAT=2).
   
4) Open a command line window and cd to your compilation directory.
   Type 'make' to start the compilation and keep your fingers crossed.

In case you need to view or edit any of the files, you can process them
first with the 'unix2dos' command bundled with the windows fortran
distribution and edit them with notepad.

2006/02/04 <akohlmey@cmm.chem.upenn.edu>
