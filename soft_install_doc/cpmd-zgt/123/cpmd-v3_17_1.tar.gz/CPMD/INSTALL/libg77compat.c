/* f2c compatibility layer for g77 compiled BLAS and LAPACK libraries. */
/* tested with ATLAS and ACML. installation instructions.
 * - compile with: gcc -c -O libg77compat.c
 * - delete xerbla.o from ATLAS/ACML, e.g. with: ar d libacml.a xerbla.o
 * - add this object with: ar rcsv libacml.a libg77compat.o
 * the resulting library can now be used regardless of the fortran runtime,
 * i.e. you can use the thusly patched libacml for g77 with intel ifort.
 */

/************************************************************************/
/* return accumulated user cpu time of current process in seconds */

#if defined(__WINNT)
double second_(void)
{
    return 0.0;
}

double dsecnd_(void)
{
    return 0.0L;
}

#else

#include <sys/times.h>
#include <unistd.h>

/* single precision version */
double second_(void)
{
    float retval;
    struct tms buf;

    times(&buf);
    retval = ((float) buf.tms_utime) / ( (float) sysconf(_SC_CLK_TCK));
    
    return retval;
}

/* double precision version */
double dsecnd_(void)
{
    double retval;
    struct tms buf;
    
    times(&buf);
    retval = ((double) buf.tms_utime) / ( (double) sysconf(_SC_CLK_TCK));
    
    return retval;
}
#endif

/************************************************************************/
/* lapack error handler */

#include <stdio.h>
#include <stdlib.h>

void xerbla_(char *srname, int *info, int len)
{
    char c_srname[7];
    int i;

    if (len > 6) len = 6;
    
    for (i = 0; i < len; ++i) {
        c_srname[i] = srname[i];
    }
    c_srname[len] = '\0';
    
    fprintf(stderr, " ** On entry to %6s parameter number %2d had "
            "an illegal value\n", c_srname, *info);
    exit(1);
    return;
}

/************************************************************************/
/* f2c library functions */
#include <math.h>

typedef struct { float  re, im; } complex;
typedef struct { double re, im; } dcomplex;

#if defined(abs)
#undef abs
#endif

static const double log10_of_e = 0.43429448190325182765112891891660508229439700580366L;

/* helper functions */
/* absolute of a complex */
static double f__cabs(double re, double im)
{
    double tmp;

    if(re < 0) re = -re;

    if(im < 0) im = -im;

    if(im > re) {
        tmp = re;
        re = im;
        im = tmp;
    }

    if( (re+im) == re)  return(re);

    tmp = im/re;
    tmp = re*sqrt(1.0 + tmp*tmp);  /*overflow!!*/
    return(tmp);
}


/* absolute of single precision complex */
double c_abs(complex *z)
{
    return f__cabs( z->re, z->im );
}

/* absolute of double precision complex */
double z_abs(dcomplex *z)
{
    return f__cabs( z->re, z->im );
}

/* exponential of single precision complex */
void c_exp(complex *r, complex *z)
{
        double ez, zi;

        zi = z->im;
        ez = exp(z->re);

        r->re = ez * cos(zi);
        r->im = ez * sin(zi);
}

/* exponential of double precision complex */
void z_exp(dcomplex *r, dcomplex *z)
{
        double ez, zi;

        zi = z->im;
        ez = exp(z->re);

        r->re = ez * cos(zi);
        r->im = ez * sin(zi);
}


/* single precision base 10 logarithm */
double r_lg10(float *x)
{
    return log10_of_e * log(*x);
}


/* double precision base 10 logarithm */
double d_lg10(double *x)
{
    return log10_of_e * log(*x);
}


/* double precision power function */
double pow_dd_wrap(double *x, double *y)
{
    return pow(*x, *y);
}


/* square root of a single precision complex */
void c_sqrt(complex *r, complex *z)
{
    double mag, t, zr, zi;

    zr = z->re;
    zi = z->im;

    if ( (mag = f__cabs(zr, zi)) == 0.0L) {

        r->re = r->im = 0.0L;

    } else {

        if (zr > 0.0L) {

            r->re = t = sqrt(0.5 * (mag + zr) );
            t = zi / t;
            r->im = 0.5 * t;

        } else {

            t = sqrt(0.5 * (mag - zr) );

            if (zi < 0)  t = -t;

            r->im = t;
            t = zi / t;
            r->re = 0.5 * t;
        }
    }
}

/* square root of a double precision complex */
void z_sqrt(dcomplex *r, dcomplex *z)
{
    double mag, t, zr, zi;

    zr = z->re;
    zi = z->im;

    if ( (mag = f__cabs(zr, zi)) == 0.0L) {

        r->re = r->im = 0.0L;

    } else {

        if (zr > 0.0L) {

            r->re = t = sqrt(0.5 * (mag + zr) );
            t = zi / t;
            r->im = 0.5 * t;

        } else {

            t = sqrt(0.5 * (mag - zr) );

            if (zi < 0)  t = -t;

            r->im = t;
            t = zi / t;
            r->re = 0.5 * t;
        }
    }
}

/* concatenate two strings */

void s_cat(char *lp, char *rpp[], int rnp[], int *np, int ll)
{
	int i, nc;
	char *rp;
	int n = *np;

	for(i = 0 ; i < n ; ++i) {
		nc = ll;
		if(rnp[i] < nc)
			nc = rnp[i];
		ll -= nc;
		rp = rpp[i];
		while(--nc >= 0)
			*lp++ = *rp++;
    }
	while(--ll >= 0)
		*lp++ = ' ';
}

/* compare two strings */
int s_cmp(char *a0, char *b0, int la, int lb)
{
    register unsigned char *a, *aend, *b, *bend;
    a = (unsigned char *)a0;
    b = (unsigned char *)b0;
    aend = a + la;
    bend = b + lb;

    if(la <= lb)
	{
        while(a < aend)
            if(*a != *b)
                return( *a - *b );
            else
			{ ++a; ++b; }

        while(b < bend)
            if(*b != ' ')
                return( ' ' - *b );
            else	++b;
	}

    else
	{
        while(b < bend)
            if(*a == *b)
			{ ++a; ++b; }
            else
                return( *a - *b );
        while(a < aend)
            if(*a != ' ')
                return(*a - ' ');
            else	++a;
	}
    return(0);
}

/* assign strings:  a = b */
void s_copy(register char *a, register char *b, int la, int lb)
{
	register char *aend, *bend;

	aend = a + la;

	if(la <= lb)
			while(a < aend)
				*a++ = *b++;

	else {
		bend = b + lb;
			while(b < bend)
				*a++ = *b++;
		while(a < aend)
			*a++ = ' ';
    }
}

/* return index of string b in string a, 0 if not found */
int i_indx (char *a, char *b, int la, int lb)
{
  int i, n;
  char *s, *t, *bend;

  n = la - lb + 1;
  bend = b + lb;

  for (i = 0; i < n; ++i)
    {
      s = a + i;
      t = b;
      while (t < bend) {
	if (*s++ != *t++) {
	  goto no;
        }
      }
      return (i + 1);
    no:;
    }
  return (0);
}
/* ============================================ */

#if defined(__TEST_LIBG77COMPAT)
#include <stdio.h>

int main(int argc, char **argv) 
{
   printf("size of int: %d\n", sizeof(int));
   printf("size of g77integer: %d\n", sizeof(__g77_integer));
   return 0;
} 
#endif
