#if defined(MYRINET) || defined(CRAY_XT3) || defined(__WINNT) \
    || defined(FFT_FFTW) || defined(FFT_FFTW2) || defined(FFT_FFTW3)
/* helper function to copy fortran style (a la sun fortran) strings into
 * valid c style strings. just using the string pointers will not work,
 * since the strings are NOT zero terminated.
 *
 * WARNING: do not forget to free(2) them later!
 */
#include <string.h>
#include <stdlib.h>
char *f77strdup(s,sz)
    const char *s;
    const int sz;
{
    char *r;
    
    r = (char *)malloc(sz + 1);
    r = (char *)memcpy(r, s, sz);
    r[sz] = '\0';
    return r;
}
#endif

#if defined(CRAY_XT3)

/* The following is to buffer the stdio and stderr on the XT3 */
#include <stdio.h>
#include <malloc.h>
#include <catamount/catmalloc.h>
int bsize=65536;
char *buf,*buf2;
void
usetlbuf_( )
{
  /*  printf("XT3 : Increasing STDIO/STDERR buffer sizes\n"); */
  buf = malloc(bsize);
  buf2 = malloc(bsize);
  setvbuf( stdout, buf, _IONBF, bsize); /* _IOFBF, _IOLBF, _IONBF */
  setvbuf( stderr, buf2, _IONBF, bsize);
}

/* 
 * approximate the current memory usage on Cray XT3 by using
 * the heap_info subroutine.
 *
 * added 10/2005 by akohlmey@cmm.upenn.edu
 */

#include <stdio.h>
#include <stdlib.h>

void printmemsize_(char *sub, int len)
{

  size_t tfrags;
  unsigned long tfree, lfree, tused;
  int err;
  char *sname;

  sname = f77strdup(sub,len);

  err = heap_info(&tfrags, &tfree, &lfree, &tused);
  fprintf(stdout, " ***%8s|  CURRENT HEAP USED/FREE %8u/%8u kBytes ***\n", 
         sname, tused/1024L, tfree/1024L);
  free(sname);
  return;
}
#endif

/*-- Intel Pentium / Intel Fortran Compiler  ------*/
#if defined(LINUX_IFC)

/************************************************************************ 
 * as of version 8.0 the intel fortran compiler contains the 'old' DEC
 * fortran frontend, which allocates local storage on the stack with
 * alloca() instead of using malloc(). while this helps avoiding memory
 * leaks, it needs a significantly larger stack than other codes, and
 * on machines using, e.g. redhat or fedora linux, one has to raise the
 * stacksize ulimit. it would be better to have your sysadmin do it,
 * and it cannot work with scripts for parallel jobs, so we add this
 * hack here.  Axel Kohlmeyer and Mauro Boero, 2006-12-04.
 ************************************************************************/
#include <sys/resource.h>
#include <unistd.h>
void libc_ulimit_linux_hack_(void)
{
        struct rlimit mylimit;
/* try to increase the stack size to the maximum */
        if(0 == getrlimit(RLIMIT_STACK, &mylimit)) {
        mylimit.rlim_cur=1 << 31;  /* 1 GB default */
        setrlimit(RLIMIT_STACK, &mylimit);
        }
}


/* the intel compiler for linux does not have DERF() and DERFC() */
 
# include <math.h>
 
double derf_(double *value)
{
  double erf();
  return(erf(*value)); 
}
 
double derfc_(double *value)
{
  double erfc();
  return(erfc(*value));
}
 
#endif

/* system support for pathscale EKO compiler */
/* we need fdate and signal */
#if defined(__PATHSCALE)
#include <time.h>
#include <string.h>

/* pathscale uses sun string conventions, i.e. 
 * a length byte for each string follows after 
 * the prototyped argument list.s the calling sequence
 * for fdate_() is 'CALL FDATE(STRING)'. see util.F */
void fdate_(char *str, int len) 
{
  time_t tv;
  int i;

  tv=time(NULL);
  strncpy(str,ctime(&tv),len);

  /* remove trailing 0x00 byte of c-style string */
  for (i=0; i < len; ++i) {
    if (str[i] == (char) 0) str[i] = ' '; 
  }
  return;
}

/* we use a simple BSD style 'one-trip' signal handler here. 
 * having a 'persistant' signal handler a la sigaction(2)
 * would be an advantage (the job won't crash on the second
 * occurance of a trapped and handled signal), but the semantics
 * for the others are different. better to re-install the 
 * signal handler in SOFTEX. */
void signal_(int *sig,void (*handler)(int)) {
  signal(*sig, handler);
  return;
}
#endif

/*ckk-mb For MacOSX on Intel PC(MacPro) + IFC(ifort)*/
#
#if defined(__OSX_IFC)
/*-- Intel Pentium / Intel Fortran Compiler  ------*/
/* the intel compiler for macosx does not have DERF() and DERFC() */
# include <math.h>

double derf_(double *value)
{
  double erf();
  return(erf(*value));
}

double derfc_(double *value)
{
  double erfc();
  return(erfc(*value));
}
#endif
/*ckk-mb*/

/*-- IBM ------------------------------------------*/
#if defined(__IBM) && !defined(__OSX) && !defined(__OSX_IFC) && !defined(__PWRLinux)
/*-- NOMEMINFO ------------------------------------------*/
#elif defined(__NOMEMINFO)
#include <stdlib.h>
int  printmemsize(long *value)
{
  int st =  sbrk(0);
  return((int) st);
}
/*-- DEC ALPHA ------------------------------------*/
#elif (defined(__alpha) && !defined(ALPHALINUX))
#include <stdio.h>
/* Define a givehostname function */
#include <unistd.h>
void givehostname_(name,namelen)
   char *name;
   int namelen;
 {
   int ishost;
   ishost = gethostname(name,namelen);
 }

#define PRINTMEMSIZE

/*-- DEC ALPHA ------------------------------------*/


/*-- SUN ------------------------------------------*/
#elif defined(__SUN)

#define PRINTMEMSIZE
/*-- SUN ------------------------------------------*/


/*-- SGI ------------------------------------------*/
#elif defined(__SGI)

#define PRINTMEMSIZE
/*-- SGI ------------------------------------------*/

/*--Hewlet Packard --------------------------------*/
#elif defined(__HP)
/* emulate derf derfc */
#include <math.h>

double derf_(double *value)
{
  double erf();
  return(erf(*value));
}

double derfc_(double *value)
{
  double erfc();
  return(erfc(*value));
}
#include <string.h>

void azzero_(double *a,int *n)
{
  void *memset(void *s, int c, size_t n);

  memset(a,0,(size_t) *n*sizeof(double));
  return;
}

void zazzero_(double *a,int *n)
{
  void *memset(void *s, int c, size_t n);

  memset(a,0,(size_t) *n*sizeof(double)*2);
  return;
}


#include <sys/param.h>
#include <sys/pstat.h>
#include <unistd.h>

#define ERROR { *vdata=0; *vstack=0; return; };

/* Give memory used by process */
void memme_(double *vdata, double *vstack)
{
  int pstat_getstatic(struct pst_static *buf, size_t elemsize, 
                      size_t elemcount,int index);
  int pstat_getproc(struct pst_status *buf, size_t elemsize, 
                      size_t elemcount,int index);     
  pid_t getpgid ();

  size_t elemcount;
  int    index;
  int    pagesize, chk;
  struct pst_static buf_static;
  struct pst_status buf_status;

  elemcount=1;
  index=0;
  /* get pagesize */
  chk=pstat_getstatic(&buf_static,(size_t) sizeof(buf_static),elemcount,index);
  if (chk == -1) ERROR
  pagesize = (int) buf_static.page_size;

  elemcount=0;
  index=(int) getpid();
  if (index <= 0) ERROR
  chk=pstat_getproc(&buf_status,(size_t) sizeof(buf_status),elemcount,index); 
  if (chk == -1) ERROR

  *vdata  = (double) buf_status.pst_dsize;
  *vstack = (double) buf_status.pst_ssize;

  *vdata  = *vdata /1024*(pagesize/1024);
  *vstack = *vstack/1024*(pagesize/1024);

  return;
}
/*-- Hewlet Packard -------------------------------*/


/*-- Fujitsu VPP ----------------------------------*/
#elif defined(_vpp_)

#include <sys/types.h>
#include <unistd.h>
int getuid_(void) {
  uid_t getuid(void);
  return(getuid());
}

#define PRINTMEMSIZE

/*-- Fujitsu VPP ----------------------------------*/


/*-- CRAY -----------------------------------------*/
#elif defined(CRAY) && !defined(CRAYX1)
#include <time.h>
#include <sys/types.h>
#include <string.h>
#include <fortran.h>

void FDATE_( fstring )

_fcd fstring;
{
     time_t timval;
     int slen;

     time(&timval);
     strncpy(_fcdtocp(fstring), ctime(&timval), 24);

     return;
}

#define HOSTNM_MAX  256

void HOSTNM( fstring )
_fcd fstring;
{
     char hostname[HOSTNM_MAX];
     int slen;

     gethostname(hostname, HOSTNM_MAX);

     slen = _fcdlen(fstring);
     strncpy(_fcdtocp(fstring), hostname, slen);

     return;
}

void SYSTEM( fstring )
_fcd fstring;
{
     system(_fcdtocp(fstring));
     return;
}

/* This works on T3E in Grenoble. */
/* It could not work for other CRAY computers (T.D.) */
/* Give the job time limit */
#if defined(JOBLIMIT)
#include <sys/category.h>
#include <sys/time.h>
#include <sys/resource.h>
/* Give time limit for Job (seconds) */
/* time = limit(C_PROC, 0, L_CPU, -1); */
/* printf("The current CPU time limit is %ld clock ticks or %ld sec\n",*/
/*           time, time/CLK_TCK); */
/* CLK_TCK defined in time.h> */
/*  */
/* time = limit(C_JOB, 0, L_MPPT, -1); */
/* printf("The current JOB time limit is %d seconds\n", time); */
/*  */
/* mem = limit(C_PROC, 0, L_MEM, -1); */
/* printf( */
/* "The current memory limit is %ld blocks,  %ld words, or %.1f Mw\n",*/
/* mem, mem * 512, (mem * 512)/1048576.); */
long GETJOBLIMIT ()
{
  long time;
#if defined(T3D) || defined(T3E)
  time = limit(C_JOB, 0, L_MPPT, -1);
#else
  time = limit(C_PROC, 0, L_CPU, -1)/CLK_TCK;
#endif
  return(time);
}
#endif
/*-- CRAY -----------------------------------------*/


/*-- SR2201 ---------------------------------------*/
#elif defined(__SR2201) || defined(__SR8000)
#include <sys/types.h>
#include <string.h>

void SYSTEM( fstring )
char fstring[100];
{
     system( fstring );
     return;
}
/*-- SR2201 ---------------------------------------*/

/*-- Linux ----------------------------------------*/
#elif (defined(__Linux) || defined(ALPHALINUX) || defined(__PWRLinux) || defined(__WINNT))

/*
 * redirect stdout from c to /dev/null. needed for path integrals
 */

#include <stdio.h>

void silentstdout_(void)
{
#if !defined(__WINNT)
        stdout=fopen("/dev/null", "w+");
#endif
        return;
}

#if !defined(CRAY_XT3)
/* 
 * get the current resident set size from the /proc filesystem.  this is
 * _much_ faster and far more stable and portable across linux kernel
 * versions than parsing some obscure ps output which sometimes changes
 * with every new moon.
 * Cray XT3 does not have /proc, so we cannot use this.
 * 
 * added 07/2001 by axel.kohlmeyer@theochem.rub.de
 * changed from RSS to VSIZE 04/2004 by axel.kohlmeyer@theochem.rub.de
 * 10/2005 disabled for Cray XT3, alternative at the top of the file
 * by akohlmey@cmm.upenn.edu.
 */

#include <stdio.h>
#include <string.h>

#if defined(ALPHALINUX)
# define PGSIZE 8192U
#else
# define PGSIZE 4096U
#endif
#define MYBUFSIZE 1024
void printmemsize_(void)
{
    FILE *pf;
    unsigned int sz, rss;
    char buf[MYBUFSIZE], *ptr;

    rss = sz = 0;
    strcpy(buf,"(unknown)");

    /* newer linux kernels support the more convenient /proc/self/status
     * file, so we try read that one first. */
    pf = fopen("/proc/self/status", "r");
    if (pf) {
        fread(buf, MYBUFSIZE, 1, pf);
        buf[MYBUFSIZE - 1] = 0;
        fclose(pf);

        /* get the total size */
        ptr = strstr(buf, "VmSize");
        if (ptr != NULL) {
            sscanf(ptr, "%*s %u", &sz);
        }
        
        /* get the resident set size */
        ptr = strstr(buf, "VmRSS");
        if (ptr != NULL) {
            sscanf(ptr, "%*s %u", &rss);
        }
        
        printf("%7u/%7u", rss, sz);
    } else {
        pf = fopen("/proc/self/stat", "r");
        if (pf) {
            fread(buf, MYBUFSIZE, 1, pf);
            buf[MYBUFSIZE - 1] = 0;
            fclose(pf);
            sscanf(buf, "%*d %*s %*c %*d %*d %*d %*d %*d %*u %*u "
                   "%*u %*u %*u %*d %*d %*d %*d %*d %*d %*u %*u "
                   "%*d %u %u", &sz, &rss);
            printf("%7u/%7u", PGSIZE / 1024U * rss, sz / 1024U);
        } else {
            printf("(unknown)");
        }
    }
    (void)fflush(stdout);
    return;
}
#undef MYBUFSIZE
#undef PGSIZE
#endif /* !CRAY_XT3 */

/* myrinet's GM libraries do not allow 'call system'.
 * so we emulate the various operations here. 
 * this also applies to architectures with microkernels,
 * e.g. Cray XT3 and BG/L(?).
 * maybe this should be done for all architectures, anyway.
 *
 * last change 07/2001 by axel.kohlmeyer@theochem.ruhr-uni-bochum.de
 * revised for Cray XT3 on 10/2005 by akohlmey@cmm.upenn.edu
 */
#if defined(MYRINET) || defined(CRAY_XT3) || defined(__WINNT)
#include <stdio.h>

#if defined(CRAY_XT3)
#include <catamount/catmalloc.h>
#endif

/* delete a file */
void rmfile_(n,sz)
    char *n;
    int   sz;
{
    char *name;
    
    name = f77strdup(n,sz);
    remove(name);
    free(name);
    return;
}

/* copy a file */
#if defined(CRAY_XT3)
#define IOBUFSIZE 32*1024*1024
#else
#define IOBUFSIZE 1024
#endif
void cpfile_(o, n, os, ns) 
    const char *o;
    const char *n;
    int os;
    int ns;
{
    char *old, *new, *iobuf;
    int sz;
    FILE *op, *np;
    
    old = f77strdup(o,os);
    new = f77strdup(n,ns);
    iobuf = malloc(IOBUFSIZE);

    op = fopen(old, "r");
    np = fopen(new, "w");
    
    while(!(feof(op)) || (ferror(op))) {
        sz = fread(iobuf, 1, IOBUFSIZE, op);
        fwrite(iobuf, 1, sz, np);
    }

    fclose(op);
    fclose(np);

    free(old);
    free(new);
    free(iobuf);
    return;
}
#undef IOBUFSIZE

#endif /* defined(MYRINET) || defined(CRAY_XT3) || defined (__WINNT) */


/*-- Other computers ------------------------------*/
#elif !defined(__NEC) && !defined (__SGI) && !defined(__SUN) && !defined(__OSX) && !defined(__OSX_IFC)

#endif
/*-- Other computers ------------------------------*/

#ifdef LINUX_IA64_INTEL
/* emulate derf derfc */
#include <math.h>

double derf_(double *value)
{
  double erf();
  return(erf(*value));
}

double derfc_(double *value)
{
  double erfc();
  return(erfc(*value));
}
#endif

/*-- PRINTMEMSIZE -----------------------------------*/
#if defined(PRINTMEMSIZE)

#include <sys/fcntl.h>   /* define O_RDONLY */
#include <sys/procfs.h>  /* define PIOCPSINFO and PIOCGETPR */

#include <limits.h>      /* PID_MAX */
#include <string.h>      /* strlen */     
#include <math.h>        /* log10 */
#include <stdio.h>       /* printf */

#include <stdlib.h>      /* malloc */

/* Print Memory used by process */
void printmemsize_( void ) 
{ 
  int  fid,imax,i,j,namelen,n;
  size_t l;
  long vrtsize;
  char sproc[] = "/proc/";
  char *pname;
  prpsinfo_t info; 
  
  imax = (int)log10( (double)PID_MAX)+1;
  l = strlen(sproc);
  pname = malloc( (imax+(int)l)*sizeof(char) );
  if( ! pname) {
    (void)fprintf(stdout,"\n printmemsize! pname not allocated!\n");
    (void)fflush(stdout);
    return;
  }
  n = getpid();
  (void)sprintf (pname,"/proc/%d",n);
  /* First, we try %d */
  fid = open (pname, O_RDONLY);
  if (fid == -1) {
    /* Failed, we try %n.nd */
    (void)sprintf(pname,"%s",sproc);
    j = (int)log10( (double)n)+1;
    for (i=0; i<imax-j; i++) {
      (void)sprintf(&pname[l+i],"0");
    }
    (void)sprintf(&pname[l+imax-j],"%d",n);
    fid = open (pname, O_RDONLY);
  }
  if( ioctl(fid, PIOCPSINFO, (char *)&info) ) {
    (void)fprintf(stdout,"\n printmemsize! error in ioctl\n");
    (void)fflush(stdout);
    return;    
  }
  close (fid);
  /* We use the image size */
  vrtsize = info.pr_size*getpagesize()/1000;
  (void)fprintf(stdout,"%7ld",vrtsize);
  (void)fflush(stdout);
  /* Deallocation */
  free(pname);
} /* printmemsize_ */
#endif

/*-- END PRINTMEMSIZE --*/


/* fortran API for im-/export of fftw wisdom */

#if defined(FFT_FFTW) || defined (FFT_FFTW2) || defined (FFT_FFTW3)

#include <stdio.h>

#if defined(FFT_FFTW3)
#define MY_FFTW_SUCCESS 1
#else
#define MY_FFTW_SUCCESS 0
#endif

void fftw_export_wisdom_to_file(FILE *);
int  fftw_import_wisdom_from_file(FILE *);
void fftw_forget_wisdom(void);

void fftw_f77_export_wisdom_to_file_(const char *wisdom, int size)
{
      const char *fn;
      FILE *fp;

      fn=f77strdup(wisdom,size);
      fp=fopen(fn,"w");
      if(fp) {
          fftw_export_wisdom_to_file(fp);
          fclose(fp);
      }
      free((void *)fn);
}

void fftw_f77_import_wisdom_from_file_(const char *wisdom, int *ierr, int size)
{
      const char *fn;
      FILE *fp;
      int retval;

      *ierr=1;
      fn=f77strdup(wisdom,size);
      fp=fopen(fn,"r");
      if(fp) {
          retval=fftw_import_wisdom_from_file(fp);
          if(retval == MY_FFTW_SUCCESS)
              *ierr=0;
          fclose(fp);
      }
      free((void *)fn);
}

void fftw_f77_forget_wisdom_(void)
{
    fftw_forget_wisdom();
}

/* for compatibility with different underscoring conventions. 
 * using #pragma weak simpler, but is not portable... */
void fftw_f77_export_wisdom_to_file(const char *wisdom, int size) 
{
    fftw_f77_export_wisdom_to_file_(wisdom,size);
}
void fftw_f77_export_wisdom_to_file__(const char *wisdom, int size)
{
    fftw_f77_export_wisdom_to_file_(wisdom,size);
}

void fftw_f77_import_wisdom_from_file(const char *wisdom, int *ierr, int size)
{
    fftw_f77_import_wisdom_from_file_(wisdom,ierr,size);
}
void fftw_f77_import_wisdom_from_file__(const char *wisdom, int *ierr, int size)
{
    fftw_f77_import_wisdom_from_file_(wisdom,ierr,size);
}

void fftw_f77_forget_wisdom(void)
{
    fftw_forget_wisdom();
}
void fftw_f77_forget_wisdom__(void)
{
    fftw_forget_wisdom();
}

#endif
